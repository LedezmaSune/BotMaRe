(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[837],{714:(e,a,t)=>{"use strict";t.d(a,{A:()=>r});var s=t(1339);let l={name:"arrow-left",size:24,node:[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]]};l.node;let r=(0,s.A)(l)},1738:(e,a,t)=>{"use strict";t.d(a,{A:()=>r});var s=t(1339);let l={name:"eye",size:24,node:[["path",{d:"M2.062 12.348a1 1 0 0 1 0-.696 10.75 10.75 0 0 1 19.876 0 1 1 0 0 1 0 .696 10.75 10.75 0 0 1-19.876 0",key:"1nclc0"}],["circle",{cx:"12",cy:"12",r:"3",key:"1v7zrd"}]]};l.node;let r=(0,s.A)(l)},2170:(e,a,t)=>{"use strict";t.d(a,{A:()=>r});var s=t(1339);let l={name:"webhook",size:24,node:[["path",{d:"M18 16.98h-5.99c-1.1 0-1.95.94-2.48 1.9A4 4 0 0 1 2 17c.01-.7.2-1.4.57-2",key:"q3hayz"}],["path",{d:"m6 17 3.13-5.78c.53-.97.1-2.18-.5-3.1a4 4 0 1 1 6.89-4.06",key:"1go1hn"}],["path",{d:"m12 6 3.13 5.73C15.66 12.7 16.9 13 18 13a4 4 0 0 1 0 8",key:"qlwsc0"}]]};l.node;let r=(0,s.A)(l)},3278:(e,a,t)=>{"use strict";t.d(a,{A:()=>r});var s=t(1339);let l={name:"copy",size:24,node:[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]};l.node;let r=(0,s.A)(l)},4250:(e,a,t)=>{Promise.resolve().then(t.bind(t,8758))},4527:(e,a,t)=>{"use strict";t.d(a,{A:()=>r});var s=t(1339);let l={name:"shield-alert",size:24,node:[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}],["path",{d:"M12 8v4",key:"1got3b"}],["path",{d:"M12 16h.01",key:"1drbdi"}]]};l.node;let r=(0,s.A)(l)},5310:(e,a,t)=>{"use strict";t.d(a,{A:()=>r});var s=t(1339);let l={name:"shield",size:24,node:[["path",{d:"M20 13c0 5-3.5 7.5-7.66 8.95a1 1 0 0 1-.67-.01C7.5 20.5 4 18 4 13V6a1 1 0 0 1 1-1c2 0 4.5-1.2 6.24-2.72a1.17 1.17 0 0 1 1.52 0C14.51 3.81 17 5 19 5a1 1 0 0 1 1 1z",key:"oel41y"}]]};l.node;let r=(0,s.A)(l)},5621:(e,a,t)=>{"use strict";t.d(a,{A:()=>r});var s=t(1339);let l={name:"check",size:24,node:[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]};l.node;let r=(0,s.A)(l)},7969:(e,a,t)=>{"use strict";t.d(a,{O:()=>c});var s=t(5287);t(7535);var l=t(5628),r=t.n(l),o=t(4527),n=t(8276),i=t(714),d=t(9275);function c({moduleId:e,moduleName:a,children:t}){let{isModuleEnabled:l,licensingState:x}=(0,d.Y)();if(l(e))return(0,s.jsx)(s.Fragment,{children:t});let p=a||e.toUpperCase();return(0,s.jsxs)("div",{className:"flex flex-col items-center justify-center min-h-[60vh] text-center p-6 sm:p-12 animate-in fade-in zoom-in-95 duration-300",children:[(0,s.jsx)("div",{className:"w-20 h-20 rounded-3xl bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400 mb-6 shadow-[0_0_30px_rgba(245,158,11,0.2)]",children:(0,s.jsx)(o.A,{size:40})}),(0,s.jsxs)("span",{className:"px-3.5 py-1 rounded-full text-[10px] font-black uppercase tracking-widest bg-amber-500/10 border border-amber-500/30 text-amber-400 mb-3 inline-flex items-center gap-1.5",children:[(0,s.jsx)(n.A,{size:12})," Plan ",x?.plan||"B\xe1sico"]}),(0,s.jsxs)("h2",{className:"text-2xl sm:text-3xl font-black tracking-tight text-white mb-3",children:["M\xf3dulo ",(0,s.jsx)("span",{className:"bg-gradient-to-r from-amber-400 to-orange-500 bg-clip-text text-transparent",children:p})," no disponible"]}),(0,s.jsx)("p",{className:"text-sm text-app-text-muted max-w-md mb-8 leading-relaxed",children:"Esta funci\xf3n requiere un plan superior o no ha sido habilitada para esta instancia. Contacta a tu proveedor de servicio para desbloquear este m\xf3dulo."}),(0,s.jsxs)(r(),{href:"/",className:"inline-flex items-center gap-2 px-6 py-3 rounded-2xl bg-cyan-500/10 hover:bg-cyan-500/20 border border-cyan-500/30 text-cyan-400 font-bold text-xs uppercase tracking-widest transition-all active:scale-95 shadow-lg shadow-cyan-500/10",children:[(0,s.jsx)(i.A,{size:16})," Volver al Inicio"]})]})}},8276:(e,a,t)=>{"use strict";t.d(a,{A:()=>r});var s=t(1339);let l={name:"sparkles",size:24,node:[["path",{d:"M11.017 2.814a1 1 0 0 1 1.966 0l1.051 5.558a2 2 0 0 0 1.594 1.594l5.558 1.051a1 1 0 0 1 0 1.966l-5.558 1.051a2 2 0 0 0-1.594 1.594l-1.051 5.558a1 1 0 0 1-1.966 0l-1.051-5.558a2 2 0 0 0-1.594-1.594l-5.558-1.051a1 1 0 0 1 0-1.966l5.558-1.051a2 2 0 0 0 1.594-1.594z",key:"1s2grr"}],["path",{d:"M20 2v4",key:"1rf3ol"}],["path",{d:"M22 4h-4",key:"gwowj6"}],["circle",{cx:"4",cy:"20",r:"2",key:"6kqj1y"}]],aliases:["stars"]};l.node;let r=(0,s.A)(l)},8758:(e,a,t)=>{"use strict";t.r(a),t.d(a,{default:()=>g});var s=t(5287),l=t(7535),r=t(2170),o=t(1339);let n={name:"link",size:24,node:[["path",{d:"M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71",key:"1cjeqo"}],["path",{d:"M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71",key:"19qd67"}]]};n.node;let i=(0,o.A)(n);var d=t(5621),c=t(3278),x=t(5310);let p={name:"eye-off",size:24,node:[["path",{d:"M10.733 5.076a10.744 10.744 0 0 1 11.205 6.575 1 1 0 0 1 0 .696 10.747 10.747 0 0 1-1.444 2.49",key:"ct8e1f"}],["path",{d:"M14.084 14.158a3 3 0 0 1-4.242-4.242",key:"151rxh"}],["path",{d:"M17.479 17.499a10.75 10.75 0 0 1-15.417-5.151 1 1 0 0 1 0-.696 10.75 10.75 0 0 1 4.446-5.143",key:"13bj9a"}],["path",{d:"m2 2 20 20",key:"1ooewy"}]]};p.node;let h=(0,o.A)(p);var m=t(1738);function u({apiKey:e}){let[a,t]=(0,l.useState)(null),[o,n]=(0,l.useState)("gas"),[p,b]=(0,l.useState)(""),[g,j]=(0,l.useState)(!1),y=`${p}/api/webhooks/incoming`;(0,l.useEffect)(()=>{b(window.location.origin)},[]);let f=(e,a)=>{navigator.clipboard.writeText(e),t(a),setTimeout(()=>t(null),2e3)},v={gas:`// Google Apps Script (GAS) - Google Sheets/Forms
function enviarWhatsApp() {
  var url = "${y}?apikey=${e}";
  
  var payload = {
    "phone": "5215555555555",
    "message": "Hola desde Google Sheets! 📊"
  };
  
  var options = {
    "method": "post",
    "contentType": "application/json",
    "payload": JSON.stringify(payload)
  };
  
  var response = UrlFetchApp.fetch(url, options);
  Logger.log(response.getContentText());
}`,go:`// Go (Golang)
package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
)

func main() {
	url := "${y}"
	payload := map[string]string{
		"phone":   "5215555555555",
		"message": "Hola desde Go! 🐹",
	}
	jsonValue, _ := json.Marshal(payload)

	req, _ := http.NewRequest("POST", url, bytes.NewBuffer(jsonValue))
	req.Header.Set("Content-Type", "application/json")
	req.Header.Set("x-api-key", "${e}")

	client := &http.Client{}
	resp, _ := client.Do(req)
	defer resp.Body.Close()

	fmt.Println("Enviado. Status:", resp.Status)
}`,node:`// Node.js (Axios / Fetch)
const axios = require('axios');

async function enviarMensaje() {
  try {
    const response = await axios.post('${y}', {
      phone: '5215555555555',
      message: 'Hola desde Node.js! 🚀'
    }, {
      headers: {
        'x-api-key': '${e}',
        'Content-Type': 'application/json'
      }
    });
    console.log(response.data);
  } catch (error) {
    console.error(error);
  }
}

enviarMensaje();`,curl:`# Bash / cURL (Zapier Custom Request)
curl -X POST "${y}" \\
     -H "x-api-key: ${e}" \\
     -H "Content-Type: application/json" \\
     -d '{
           "phone": "5215555555555",
           "message": "Hola desde cURL! 💻"
         }'`};return(0,s.jsxs)("div",{className:"h-full flex flex-col p-6 space-y-6 overflow-y-auto",children:[(0,s.jsxs)("header",{children:[(0,s.jsxs)("h1",{className:"text-3xl font-bold text-white flex items-center gap-3",children:[(0,s.jsx)(r.A,{className:"w-8 h-8 text-emerald-500"}),"Webhooks & API"]}),(0,s.jsx)("p",{className:"text-slate-400 mt-2",children:"Conecta BotMaRe con cientos de aplicaciones externas usando Zapier, Make, Google Sheets o tu propio c\xf3digo."})]}),(0,s.jsxs)("div",{className:"grid grid-cols-1 lg:grid-cols-2 gap-6",children:[(0,s.jsxs)("div",{className:"premium-glass p-6 rounded-2xl border border-app-border/30",children:[(0,s.jsxs)("div",{className:"flex items-center gap-2 mb-4",children:[(0,s.jsx)(i,{className:"w-5 h-5 text-blue-400"}),(0,s.jsx)("h2",{className:"text-lg font-bold text-white",children:"Endpoint URL"})]}),(0,s.jsxs)("div",{className:"flex items-center gap-3 bg-black/40 p-3 rounded-xl border border-white/5",children:[(0,s.jsx)("code",{className:"text-sm text-blue-300 flex-1 truncate",children:y}),(0,s.jsx)("button",{onClick:()=>f(y,"url"),className:"p-2 hover:bg-white/10 rounded-lg transition-colors",children:"url"===a?(0,s.jsx)(d.A,{className:"w-4 h-4 text-emerald-400"}):(0,s.jsx)(c.A,{className:"w-4 h-4 text-slate-400"})})]})]}),(0,s.jsxs)("div",{className:"premium-glass p-6 rounded-2xl border border-app-border/30",children:[(0,s.jsxs)("div",{className:"flex items-center gap-2 mb-4",children:[(0,s.jsx)(x.A,{className:"w-5 h-5 text-orange-400"}),(0,s.jsx)("h2",{className:"text-lg font-bold text-white",children:"API Key de Seguridad"})]}),(0,s.jsxs)("div",{className:"flex items-center gap-3 bg-black/40 p-3 rounded-xl border border-white/5",children:[(0,s.jsx)("code",{className:"text-sm text-orange-300 flex-1 font-mono",children:g?e:`••••••••••••••••••••${e.slice(-4)}`}),(0,s.jsx)("button",{onClick:()=>j(!g),className:"p-2 hover:bg-white/10 rounded-lg transition-colors",title:g?"Ocultar":"Mostrar",children:g?(0,s.jsx)(h,{className:"w-4 h-4 text-slate-400"}):(0,s.jsx)(m.A,{className:"w-4 h-4 text-slate-400"})}),(0,s.jsx)("button",{onClick:()=>f(e,"key"),className:"p-2 hover:bg-white/10 rounded-lg transition-colors",title:"Copiar",children:"key"===a?(0,s.jsx)(d.A,{className:"w-4 h-4 text-emerald-400"}):(0,s.jsx)(c.A,{className:"w-4 h-4 text-slate-400"})})]}),(0,s.jsxs)("div",{className:"text-xs text-slate-500 mt-3 space-y-1 bg-black/20 p-3 rounded-lg border border-white/5",children:[(0,s.jsx)("strong",{className:"text-emerald-400 mb-1 block",children:"\uD83D\uDCA1 Instrucciones de Uso:"}),(0,s.jsxs)("p",{children:["Tu llave maestra se encuentra en tu archivo ",(0,s.jsx)("code",{className:"text-slate-300 bg-white/10 px-1 rounded",children:".env"})," como ",(0,s.jsx)("code",{className:"text-slate-300 bg-white/10 px-1 rounded",children:"WEBHOOK_API_KEY"}),"."]}),(0,s.jsx)("p",{children:"Puedes enviarla en las peticiones de 3 formas distintas:"}),(0,s.jsxs)("ul",{className:"list-disc pl-4 space-y-1 mt-1 text-slate-400",children:[(0,s.jsxs)("li",{children:["Como Header: ",(0,s.jsx)("code",{className:"text-slate-300",children:"x-api-key: tu_llave"})]}),(0,s.jsxs)("li",{children:["Como Header: ",(0,s.jsx)("code",{className:"text-slate-300",children:"Authorization: Bearer tu_llave"})]}),(0,s.jsxs)("li",{children:["En la URL: ",(0,s.jsx)("code",{className:"text-slate-300",children:"?apikey=tu_llave"})]})]})]})]})]}),(0,s.jsxs)("div",{className:"premium-glass rounded-2xl border border-app-border/30 overflow-hidden flex flex-col flex-1 min-h-[400px]",children:[(0,s.jsx)("div",{className:"flex border-b border-app-border/30 bg-black/20",children:[{id:"gas",label:"Google Apps Script"},{id:"go",label:"Go (Golang)"},{id:"node",label:"Node.js"},{id:"curl",label:"cURL / Zapier"}].map(e=>(0,s.jsx)("button",{onClick:()=>n(e.id),className:`px-6 py-4 text-sm font-medium transition-colors border-b-2 ${o===e.id?"border-emerald-500 text-emerald-400 bg-white/5":"border-transparent text-slate-400 hover:text-slate-200 hover:bg-white/5"}`,children:e.label},e.id))}),(0,s.jsxs)("div",{className:"relative flex-1 bg-[#0d1117] p-6",children:[(0,s.jsxs)("button",{onClick:()=>f(v[o],"snippet"),className:"absolute top-4 right-4 flex items-center gap-2 px-3 py-2 bg-white/10 hover:bg-white/20 rounded-lg transition-colors text-xs text-white",children:["snippet"===a?(0,s.jsx)(d.A,{className:"w-4 h-4 text-emerald-400"}):(0,s.jsx)(c.A,{className:"w-4 h-4"}),"snippet"===a?"Copiado!":"Copiar c\xf3digo"]}),(0,s.jsx)("pre",{className:"text-sm text-slate-300 font-mono overflow-x-auto h-full",children:(0,s.jsx)("code",{children:v[o]})})]})]})]})}var b=t(7969);function g(){return(0,s.jsx)(b.O,{moduleId:"webhooks",moduleName:"Webhooks",children:(0,s.jsx)(u,{apiKey:"LLAVE_NO_CONFIGURADA"})})}}},e=>{e.O(0,[351,628,275,519,234,358],()=>e(e.s=4250)),_N_E=e.O()}]);